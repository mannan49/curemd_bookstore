
-- Stored procedure to get all books
CREATE PROCEDURE GetAllBooks
AS
BEGIN
    SELECT Id, Title, Author, Genre, ImageUrl, Price
    FROM Books;
END;

-- Stored procedure to get a book by ID
CREATE PROCEDURE GetBooksById
    @Id INT
AS
BEGIN
    SELECT Id, Title, Author, Genre, ImageUrl, Price
    FROM Books
    WHERE Id = @Id;
END;

-- Stored procedure to add a new book
CREATE PROCEDURE AddBook
    @Title NVARCHAR(255),
    @Author NVARCHAR(255),
    @Genre NVARCHAR(255),
    @ImageUrl NVARCHAR(255),
    @Price DECIMAL(18, 2)
AS
BEGIN
    INSERT INTO Books (Title, Author, Genre, ImageUrl, Price)
    VALUES (@Title, @Author, @Genre, @ImageUrl, @Price);
END;

-- Stored procedure to update an existing book
CREATE PROCEDURE UpdateBook
    @Id INT,
    @Title NVARCHAR(255),
    @Author NVARCHAR(255),
    @Genre NVARCHAR(255),
    @ImageUrl NVARCHAR(255),
    @Price DECIMAL(18, 2)
AS
BEGIN
    UPDATE Books
    SET 
        Title = @Title,
        Author = @Author,
        Genre = @Genre,
        ImageUrl = @ImageUrl,
        Price = @Price
    WHERE Id = @Id;
END;

-- Stored procedure to delete a book
CREATE PROCEDURE DeleteBook
    @Id INT
AS
BEGIN
    DELETE FROM Books
    WHERE Id = @Id;
END;

-- Stored procedure to get books by author name
CREATE PROCEDURE GetBookByauthorName
    @Author NVARCHAR(255)
AS
BEGIN
    SELECT Id, Title, Author, Genre, ImageUrl, Price
    FROM Books
    WHERE Author = @Author;
END;
