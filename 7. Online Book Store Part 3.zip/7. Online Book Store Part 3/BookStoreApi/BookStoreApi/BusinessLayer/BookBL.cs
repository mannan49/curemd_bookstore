﻿using System.Collections.Generic;
using BookStoreApi.Models;
using BookStoreApi.DataAccessLayer;

namespace BookStoreApi.BusinessLogicLayer
{
    public class BookBL
    {
        private BookDAL _bookDAL;

        public BookBL(BookDAL bookDAL)
        {
            this._bookDAL = bookDAL;
        }

        public List<Book> GetBooks()
        {
            return _bookDAL.GetBooks();
        }

        public Book GetBook(int id)
        {
            return _bookDAL.GetBook(id);
        }

        public void AddBook(Book book)
        {
            _bookDAL.AddBook(book);
        }

        public void UpdateBook(Book book)
        {
            _bookDAL.UpdateBook(book);
        }

        public void DeleteBook(int id)
        {
            _bookDAL.DeleteBook(id);
        }
    }
}
